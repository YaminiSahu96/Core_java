package lists;

import java.util.ArrayList;
import java.util.Scanner;

import com.app.core.Courses;
import com.app.core.Student;

import cust_excs.StudentHandlingException;
import utils.ValidationUtils;
import static utils.ValidationUtils.*;

public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (Scanner sc = new Scanner(System.in)) {
			
			ArrayList<Student> slist=new ArrayList<Student>();
			//slist.add(new Student("dac-001", "Poonam", "pk@gm", Courses.valueOf("DAC"), "50",parseNValidateDate("19/09/1991")));
			//slist.add(new Student("dac-002", "Hitesh", "hk@gm", Courses.valueOf("DAC"), "60",parseNValidateDate("19/09/1991")));
			//slist.add( new Student("dac-003", "Kaustubh", "kj@gm", Courses.valueOf("DAC"), "51",parseNValidateDate("19/09/1991")));
			boolean flag=false;
			while (!flag) {
				System.out.println(" Student mgmt System");
				System.out.println("1. Register Student");
				System.out.println("2. Display");
				System.out.println("3.Exit");
				System.out.println("Enter your choice");
				try
				{
				switch (sc.nextInt()) 
				{
				case 1: {
					
						System.out.println("Enter student details :");
					
						Student stud = new Student(sc.next(), validateName(sc.next()), validateEmail(sc.next()), validateCourses(sc.next()), sc.next(),parseNValidateDate(sc.next()));
							for (Student s : slist) {
								if (s != null) {
									if (s.equals(stud)) {
										throw new StudentHandlingException("Duplicate prn");
									}
								}
							}
								if(slist.add( stud))
									System.out.println("Student added successfully");
								else
									System.out.println("Failed to add student");
						}
						
					
					
				
					break;

				case 2: {
					
						for (Student l : slist) {
							System.out.println(l);
						}
				
				}
					break;
				}
				}
			
				catch(Exception e)
				{
					e.printStackTrace();
					//System.out.println(e.getMessage());
				}
				sc.nextLine();
}
		}catch(Exception e)
		{
			e.printStackTrace();
			//System.out.println(e.getMessage());
		}
			
	
	}
	}
