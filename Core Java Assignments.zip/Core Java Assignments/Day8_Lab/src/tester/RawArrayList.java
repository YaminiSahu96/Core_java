package tester;

import java.util.ArrayList;
import java.util.Date;

public class RawArrayList {
	
	public static void main(String[] args) {
		ArrayList l1 = new ArrayList();
		l1.add(11);
		l1.add("Str");
		l1.add(new Date());

		System.out.println(l1);
		String s = (String) l1.get(1);
		System.out.println(s);

	}
}
