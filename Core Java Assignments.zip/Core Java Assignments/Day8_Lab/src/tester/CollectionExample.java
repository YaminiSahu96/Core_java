package tester;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CollectionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer [] ints= {4,5,12,45,67,890};
		System.out.println(ints.getClass().getName());
		List<Integer> l1=Arrays.asList(ints);
		for(Integer i:l1)
		{
			System.out.println(i);
		}		
		//l1.add(23); //unsupported exception it is fixed size you cant change content of list 
	//	l1.remove(0); //unsupported exception it is fixed size you cant change content of list 
		l1.set(0, 11); //no error caz only replacement is done
		System.out.println(l1);
		System.out.println(l1.getClass().getName());
		
	}
	
}
