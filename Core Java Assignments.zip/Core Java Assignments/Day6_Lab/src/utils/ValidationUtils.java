package utils;

import com.app.core.Student;

import cust_excs.StudentHandlingException;

public class ValidationUtils {
	
	public static final int MINCHAR,MAXCHAR;
	//public static boolean flag=false;
	
public static final String[] coursearr= {"PG-DAC","PG-DAI","PG_DBDA","PG-DESD"};
	static
	{
		MINCHAR=4;
		MAXCHAR=10;
	}
	public static void validateName(String name) throws StudentHandlingException
	{
		 if (name.length()<MINCHAR)
			 throw new StudentHandlingException("Length is too short");
		 if (name.length()>MAXCHAR)
			 throw new StudentHandlingException("Length is too long");
		 //System.out.println("Valid name");
		
	}
	public static void validateEmail(String email) throws StudentHandlingException
	{
		if(email.length()<MINCHAR || !email.contains("@"))
			throw new StudentHandlingException("Please check your email id it should contains @");
		if(email.length()>MAXCHAR  || !email.contains("@")) 
			throw new StudentHandlingException("Please check your email id it should contains @");
	}
	
	public static void validateCourse(String course) throws StudentHandlingException
	{
		boolean flag=false;
		for(String s:coursearr)
		{
			if(s.equals(course))
			{
				flag=true;
				break;
			
			}
		}
		if(!flag)
		{
			throw new StudentHandlingException("Invalid course");
		}
		
			
	}

}
