package tester;

import java.util.Scanner;

import com.app.core.Student;

import cust_excs.StudentHandlingException;
import utils.ValidationUtils;

public class TestStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("How many Students ");
			int no = sc.nextInt();
			Student[] sarr = new Student[no];
			boolean flag = false;
			// Student s=null;
			String prn, name, email, course;
			String marks;

			sarr[0] = new Student("dac-001", "Poonam", "pk@gmail.com", "PG-DAC", "50");
			sarr[1] = new Student("dac-002", "Hitesh", "hk@gmail.com", "PG-DAC", "60");
			sarr[2] = new Student("dac-003", "Kaustubh", "kj@gmail.com", "PG-DAC", "51");
			int ct = 3;
			while (!flag) {
				System.out.println(" Student mgmt System");
				System.out.println("1. Add Student");
				System.out.println("2. Display");
				System.out.println("3.Exit");
				System.out.println("Enter your choice");
				switch (sc.nextInt()) {
				case 1: {
					if (ct < sarr.length) {
						System.out.println("Enter student details :");
						prn = sc.next();
						name = sc.next();
						email = sc.next();
						course = sc.next();
						marks = sc.next();
						Student stud = new Student(prn, name, email, course, marks);
						try {
						
							for (Student s : sarr) {
								if (s != null) {
									if (s.equals(stud)) {
										throw new StudentHandlingException("Duplicate prn");
									}
								}
							}
							ValidationUtils.validateName(name);
							ValidationUtils.validateEmail(email);
							ValidationUtils.validateCourse(course);
								sarr[ct++] = stud;
							
						} catch (StudentHandlingException e1) {
							// TODO Auto-generated catch block
							// e1.printStackTrace();
							System.out.println(e1.getMessage());
						}
			

						

					} else {
						System.out.println("Registration full !!!!!!");
					}
				}
					break;

				case 2: {
					
						for (Student l : sarr) {
							System.out.println(l);
						}
				
				}
					break;
				}

			}

		}
	}

}
