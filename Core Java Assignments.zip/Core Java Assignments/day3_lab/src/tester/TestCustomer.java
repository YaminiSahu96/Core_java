package tester;
import java.util.Scanner;
import com.cdac.core.*;
class TestCustomer
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the name,email,age,creditlimit");
		String name = sc.next();
		String email = sc.next();
		int age = sc.nextInt();
		double creditLimit = sc.nextDouble();
		Customer c = new Customer();
		c.display();
		Customer c1=new Customer(age,name,email,creditLimit);
		c1.display();
		Customer c2 = new Customer(age,name,email);
		c2.display();
		c.setCreditLimit(c.getCreditLimit()+1000);
		c.display();


	}
}
