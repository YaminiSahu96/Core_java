package tester;
import java.util.Scanner;
import com.cdac.core.*;

class TestStudent
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the id,name,email,age:");
		int id=sc.nextInt();
		String name=sc.next();
		String email=sc.next();
		int age=sc.nextInt();
		Student s=new Student(id,name,email,age);
	}
}
