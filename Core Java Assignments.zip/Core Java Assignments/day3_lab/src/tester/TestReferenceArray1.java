package tester;
import java.util.*;
import com.app.core.Box2;
class TestReferenceArray1 
{
	public static void main(String[] args) 
	{
			//sc
		Scanner sc=new Scanner(System.in);
		System.out.println("How many boxes ?");
		//create any array obj to hold box type of refs
		
		Box2[] boxes=new Box2[sc.nextInt()];
		System.out.println(Arrays.toString(boxes));
		//accept box dims , create boxes n display
		/*for (Box b:boxes )
		{
			b=new Box(sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
		}*/
		for(int i=0;i<boxes.length;i++)
		{
			System.out.println("Enter box dims");
			boxes[i]=new Box2(sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
		}
		//for-each
		for(Box2 b : boxes)//b=boxes[0],...b=boxes[boxes.length-1]
		{

			 b.displayDims();
			// System.out.println("Vol="+b.calcVolume());
		}
		/*for(Box2 b : boxes)
			b.setWidth(b.getWidth()*2);
			
		for(Box2 b : boxes)
		 b.displayDims();
		//display dtls via toString
		System.out.println(Arrays.toString(boxes));*/
		Box2 b1=new Box2(10,20,30);
		Box2 b2=new Box2(10,20,30);
		boolean b = b1.check(b2);
		if(b)
		{
			System.out.println("Same:");
		}
		else
		{
			System.out.println("Different:");
		}
			//b2=b2.getDoubleIt();
			//b1=b1.getDoubleIt();
			//b1.displayDims();
	
	}
}
