package array;

class MyArray 
{
	public static void main(String[] args) 
	{
		int[] myData = { 1, 2, 3, 4, 5 };
		int[] myData1 = { 1, 2, 3, 4, 5 };
		System.out.println("Using for loop");
		for(int i=0;i<myData.length;i++)
		{
			System.out.println(myData[i]);
		}

		System.out.println("Using for loop-modify");
		for(int i=0;i<myData.length;i++)
		{
			myData[i]=myData[i]*2;
			System.out.println(myData[i]);
		}


		System.out.println("Using for-each loop");
		for(int d:myData1) //d:myData1[0],d:myData1[1]...d=myData1[myDat1./length-1]
		{
			System.out.println(d);
		}
		
		System.out.println("Using for-each loop-modify");
		for(int d:myData1)
		{
			d=d*2;
			System.out.println(d);
		}

		System.out.println("Using for-each loop-modify");
		for(int d:myData1)
		{
			System.out.println(d);
		}




	//	int[] newData= doubleIt(myData);

		//System.out.println("Orig data - " 
		//+ Arrays.toString(myData));
		//myData= doubleIt(myData);
		//System.out.println("New data - " 
		//+ Arrays.toString(myData));
	}
	/*static int[] doubleIt(int[] ints) {
		int[] tmp = new int[ints.length * 2];
		for (int i = 0; i < ints.length; i++) {
			tmp[i] = ints[i] * 2;
		}
		return tmp;
	}*/
}
