package com.app.core;
public class Box2 
{
	//state --non static instance vars (fields)
	//heap
	private double width,depth,height;
	//parameterized constr
	public Box2(double w,double d,double height)
	{
		width=w;
		depth=d;
		//this -- to resolve conflict between local vs instance car
		this.height=height;
	}
	//To display box dimensions (void returning)
	public void displayDims()
	{
		System.out.println("Box Dims are : "+width+" "+depth+" "+height);
	}
	//To fetch box dimensions (string returning)
	public String fetchDims()
	{
		return "Fetched Box Dims are : "+width+" "+depth+" "+height;
	}
	//To compute volume of a box & return computed volume.
	public double calcVolume()
	{
		return width*depth*height;
	}
	//add a setter n getter for width
	public void setWidth(double width)
	{
		this.width=width;
	}
	public double getWidth()
	{
		return width;
	}
	public void setDepth(double d)
	{
		depth=d;
	}
	public double getDepth()
	{
		return depth;
	}
	public void setHeight(double h)
	{
		height=h;
	}
	public double getHeight()
	{
		return height;
	}
	public Box2 getDoubleIt()
	{
		this.width=this.width*2;
		this.height=this.height*2;
		this.depth=this.depth*2;
		return this;

	}
	public boolean check(Box2 b2)
	{
		if(this.width==b2.width && this.depth==b2.depth && this.height==b2.height)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	

}
