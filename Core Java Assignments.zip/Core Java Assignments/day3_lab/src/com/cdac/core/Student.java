package com.cdac.core;
import java.util.Scanner;
class Student 
{
	public int static id;
	public String name;
	public String email;
	public int age;
	public double gpa;

	public Student(int id,String name,String email,int age)
	{
		this.id=id;
		this.name=nema;
		this.email=email;
		this.age=age;
		Student();
	}
	public String Student()
	{
		return " id:"+id+" "+" name"+name+" email"+email+" age"+age;  
	}
	/*public void computeGPA()
	{
		
	}*/
	public void display()
	{
		System.out.println("id:"+id+" Name:"+name+" email:"+email+" Age:"+age);
	}

}
