package com.cdac.core;
import java.util.Scanner;

public class Customer
{
	private int age;
	private String name;
	private String email;
	private double creditLimit;
	public Customer(int age,String name,String email,double creditLimit)
	{
		this.age=age;
		this.name=name;
		this.email=email;
		this.creditLimit=creditLimit;
	}
	public Customer()
	{
		name="Rama";
		email="rama@gmail.com";
		age=25;
		creditLimit=10000;
	}
	public Customer(int age,String name,String email)
	{
		this(age,name,email,15000);
	}
	public String getDetails()
	{
		return "name="+name+" "+"creditLimit"+creditLimit;  
	}
	public double getCreditLimit()
	{
		return creditLimit;
	}
	public void setCreditLimit(double creditLimit)
	{
		this.creditLimit=creditLimit;
	}
	public void display()
	{
		System.out.println("Name:"+name+" Email:"+email+" Age:"+age+" CreditLimit:"+creditLimit);
	}
}