package evenoddseries;

public class EvenThread extends Thread 
{
	
	int start,end;
	EvenThread(String name, int start,int end)
	{
		super(name);
		this.start=start;
		this.end=end;
	}
	
	public void run()
	{
		
		for(int i=start;i<=end;i++)
		{
			if(i%2==0)
				System.out.println(Thread.currentThread().getName()+" "+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
