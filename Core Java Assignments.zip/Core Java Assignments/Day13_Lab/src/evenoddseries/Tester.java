package evenoddseries;

import java.util.Scanner;

public class Tester 
{
public static void main(String[] args)
{
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter the range:");
			int start=sc.nextInt();
			int end=sc.nextInt();
			EvenThread t1=new EvenThread("eventhread",start,end);
			OddThread t2=new OddThread("oddthread",start,end);
			t1.start();
			t2.start();
			System.out.println("main over");
			
			
		}
	
}
}
