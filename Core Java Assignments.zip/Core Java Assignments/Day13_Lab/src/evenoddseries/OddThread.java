package evenoddseries;

public class OddThread extends Thread {
	
	int start,end;
	OddThread(String name, int start,int end)
	{
		super(name);
		this.start=start;
		this.end=end;
	}
	
	public void run()
	{
		
		for(int i=start;i<=end;i++)
		{
			if(i%2!=0)
				System.out.println(Thread.currentThread().getName()+" "+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}


}
