package evenoddrunnable;

public class EvenRunnable implements Runnable
{
	
	int start,end;
	EvenRunnable( int start,int end)
	{
	
		this.start=start;
		this.end=end;
	}
	
	public void run()
	{
		
		for(int i=start;i<=end;i++)
		{
			if(i%2==0)
				System.out.println(Thread.currentThread().getName()+" "+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
