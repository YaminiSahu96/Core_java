package evenoddrunnable;

import java.util.Scanner;

public class Tester 
{
public static void main(String[] args)
{
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter the range:");
			int start=sc.nextInt();
			int end=sc.nextInt();
			EvenRunnable e1=new EvenRunnable(start,end);
			OddRunnable o1=new OddRunnable(start,end);
			Thread t1=new Thread(e1, "eventhread");
			Thread t2=new Thread(o1, "oddthread");
			t1.start();
			t2.start();
		
			
			try {
				Thread.sleep(7000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println("main over");
		}
	
}
}
