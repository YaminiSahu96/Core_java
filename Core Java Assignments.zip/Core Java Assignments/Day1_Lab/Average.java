class Average
{
	public static void main(String args[])
	{
		if(args.length<2)
		{
			System.out.println("Wrong data Member");
			return;
		}
		int sum=0;
		int avg;
		for(int i=0;i<args.length;i++)
		{
			sum=sum+Integer.parseInt(args[i]);
		}
		avg=sum/args.length;
		System.out.println("avg:"+avg);
		
	}
}