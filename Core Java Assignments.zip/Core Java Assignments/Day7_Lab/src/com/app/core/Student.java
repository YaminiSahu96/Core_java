package com.app.core;
import static utils.ValidationUtils.*;
import java.util.Date;

public class Student {
	private String prn, name, email;
	 Courses course;
	private String marks;
	private Date dob;

	public Student(String prn, String name, String email, Courses course, String marks,Date dob) {
		// super();
		this.prn = prn;
		this.name = name;
		this.email = email;
		this.course = course;
		this.marks = marks;
		this.dob=dob;
	
	}

	@Override
	public String toString() {
		return "Student [prn=" + prn + ", name=" + name + ", email=" + email + ", course=" + course + ", marks=" + marks+"dob="+sdf.format(dob)+ "]";
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (obj instanceof Student)
			return prn.equals(((Student) obj).prn);
		return false;
	}

}
