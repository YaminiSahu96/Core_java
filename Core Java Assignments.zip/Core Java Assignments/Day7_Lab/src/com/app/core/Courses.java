package com.app.core;

public enum Courses {
	DAC,DAI,DBDA,DESD;
	@Override
	public String toString()
	{
		return name().toUpperCase();
	}
}
