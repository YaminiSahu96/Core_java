//Day 7 
//Complete day 6 assignment if pending.
//Must have following classes --Student , StudentHandlingException ,ValidationRules,Tester .
//
//Modifications 
//Add in Student class , DOB 
//private Date dob;
//Modify constructor,toString suitably.
//Add validation rule -- dob can't be before 1st Jan 1985.
//
//Replace in Student class --course from String to enum.
//Add suitable conversion/validation method in ValidationRules class.
//
//In Tester , accept 1 student details , validate them . In case of success -- create the student instance & display its details.
//In case of errors --display error message via catch block.
//


package utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


import com.app.core.Courses;
import com.app.core.Student;

import cust_excs.StudentHandlingException;

public class ValidationUtils {
	
	public static final int MINCHAR,MAXCHAR;
	public static SimpleDateFormat sdf;
	public static Date Date;
	
	//public static boolean flag=false;
	
public static final String[] coursearr= {"PG-DAC","PG-DAI","PG_DBDA","PG-DESD"};
	static
	{
		MINCHAR=4;
		MAXCHAR=10;
		sdf = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date = sdf.parse("01/01/1985");
		} catch (ParseException e) {
			System.out.println("" + e);
		}
	}
	public static String validateName(String name) throws StudentHandlingException
	{
		 if (name.length()<MINCHAR)
			 throw new StudentHandlingException("Length is too short");
		 if (name.length()>MAXCHAR)
			 throw new StudentHandlingException("Length is too long");
	return name;
		
	}
	public static String validateEmail(String email) throws StudentHandlingException
	{
		if(email.length()<MINCHAR || !email.contains("@"))
			throw new StudentHandlingException("Please check your email id it should contains @");
		if(email.length()>MAXCHAR  || !email.contains("@")) 
			throw new StudentHandlingException("Please check your email id it should contains @");
		return email;
	}
	
	public static void validateCourse(String course) throws StudentHandlingException
	{
		boolean flag=false;
		for(String s:coursearr)
		{
			if(s.equals(course))
			{
				flag=true;
				break;
			
			}
		}
		if(!flag)
		{
			throw new StudentHandlingException("Invalid course");
		}
		
			
	}
	
	public static Date parseNValidateDate(String dob) throws ParseException,StudentHandlingException
	{
		Date d = sdf.parse(dob);
			if(d.before(Date))
			{
				throw new StudentHandlingException("Invalid Date: ");
			}
			return d;
	}
	// validate a/c type
		public static Courses validateCourses(String course) throws StudentHandlingException {
			Courses c=null;
			try
			{
			c=Courses.valueOf(course.toUpperCase());
			}
			catch(IllegalArgumentException e)
			{
				throw new StudentHandlingException("Invalid course");
			}
		
		return c;
		}
}
