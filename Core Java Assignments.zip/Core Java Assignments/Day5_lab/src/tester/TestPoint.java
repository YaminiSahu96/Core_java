package tester;



import java.util.Scanner;

import shapes.Circle;
import shapes.Point;
import shapes.Rectangle;

public class TestPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of shapes ");
		int no=sc.nextInt();
		int ct=0;
		Point[] parr = new Point[no];
		boolean flag=false;
		while(!flag)
		{
			System.out.println("*******Bounded Shapes******");
			System.out.println("1. Add Circle");
			System.out.println("2. Add Rectangle");
			System.out.println("3. Display area and perimeter");
			System.out.println("4. Exit");
			System.out.println("Enter the choice");
			switch(sc.nextInt())
			{
			case 1:
				if(ct<parr.length)
				{
				System.out.println("Enter circkle details:");
				parr[ct++]=new Circle(sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
				}break;
			case 2:
				if(ct<parr.length)
				{
				System.out.println("Enter Rectangle details:");
				parr[ct++]=new Rectangle(sc.nextDouble(),sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
				
				}break;
			case 3:
				for(Point p:parr)
				{
				if(p!=null)
				{
					if(p instanceof Circle)
					{
						System.out.println("Circle");
						System.out.println("Area="+((Circle)p).calculateArea());
						System.out.println("Perimeter="+((Circle)p).calculatePerimeter());
						((Circle)p).drawArc();
					}
					else
					{
					
							System.out.println("Rectangle");
							System.out.println("Area="+((Rectangle)p).calculateArea());
							System.out.println("Perimeter="+((Rectangle)p).calculatePerimeter());
							((Rectangle)p).diagonals();
					}
					
				}
				}break;
			case 4:
				flag=true;
				//exit(0);
			break;
			}
		}
	}

}
