package interfaces;

public interface Computable {
	public double PI=3.14;
	double calculateArea();
	double calculatePerimeter();

}
