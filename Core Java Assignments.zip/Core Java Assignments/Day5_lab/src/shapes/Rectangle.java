package shapes;

import interfaces.Computable;

public class Rectangle extends Point implements Computable{
	private double width;
	private double height;
	
	public Rectangle(double x,double y,double width,double height)
	{
		super(x,y);
		this.width=width;
		this.height=height;
	}
	public String toString()
	{
		String returnString=super.toString()+" "+width+height;
		return returnString;
	}
	@Override
	public double calculateArea() {
		return width*height;
	}
	@Override
	public double calculatePerimeter() {
		
		return 2*(width+height);
	}
	public void diagonals()
	{
	 System.out.println("diagonals of rectangle are equal in lenth");
	}

	
}
