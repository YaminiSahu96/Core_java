package shapes;
import static interfaces.Computable.PI;

import interfaces.Computable;

public class Circle extends Point implements Computable {

	double radius;
	
	public Circle(double x,double y,double radius)
	{
		super(x,y);
		this.radius=radius;
	}
	public String toString()
	{
		String returnString=super.toString()+" "+radius;
		return returnString;
	}
	@Override
	public double calculateArea()
	{
		return PI*radius*radius;
	}
	@Override
	public double calculatePerimeter() {
		// TODO Auto-generated method stub
		return 2*PI*radius;
	}
	
	public void drawArc()
	{
		System.out.println("drawing Arc ");
	}
	
}
