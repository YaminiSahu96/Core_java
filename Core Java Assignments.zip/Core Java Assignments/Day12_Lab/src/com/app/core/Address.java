package com.app.core;

import java.io.Serializable;

//Customer has multiple address
public class Address implements Serializable {
	
	private String city,state,country,phonNo; // address contains these fields 
	private String adrtype;
	

	public Address(String city, String state, String country, String phonNo, String adrtype) {
		super();
		this.city = city;
		this.state = state;
		this.country = country;
		this.phonNo = phonNo;
		this.adrtype = adrtype;
	}

	

	@Override
	public String toString() {
		return "Address [city=" + city + ", state=" + state + ", country=" + country + ", phonNo=" + phonNo
				+ ", adrtype=" + adrtype + "]";
	}



	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getCountry() {
		return country;
	}

	public String getPhonNo() {
		return phonNo;
	}

	public String getAdrtype() {
		return adrtype;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setPhonNo(String phonNo) {
		this.phonNo = phonNo;
	}

	public void setAdrtype(String adrtype) {
		this.adrtype = adrtype;
	}

	
	
	

}
