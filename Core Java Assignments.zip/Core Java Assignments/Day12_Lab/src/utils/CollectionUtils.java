package utils;

import static utils.ValidationRules.validateCustomerType;
import static utils.ValidationRules.validateDate;

import java.util.HashMap;

import com.app.core.Address;
import com.app.core.Customer;

import custom_exceptions.CustomerHandlingException;

public class CollectionUtils
{
	
	public static HashMap<String,Customer> populateStudent() 
	{
		HashMap<String,Customer> cmap= new HashMap<String,Customer>();
		try
		{
		cmap.put("pk@gmail.com", new Customer("pk@gmail.com","1234",1000.00,validateDate("12-07-1992"),validateCustomerType("SILVER")));
		cmap.put("vk@gmail.com", new Customer("vk@gmail.com","1234",1000.00,validateDate("11-02-1992"),validateCustomerType("GOLD")));
		cmap.put("sk@gmail.com", new Customer("sk@gmail.com","1234",1000.00,validateDate("13-10-1984"),validateCustomerType("GOLD")));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return cmap;
	}
	
	public static Customer getCustomerDetails(String email,HashMap<String,Customer> cmap) throws CustomerHandlingException
	{
		Customer c=cmap.get(email);
		if(c==null)
		{
			throw new CustomerHandlingException("Email does not exist. Please sign up");
		}
		return c;
	}
	
	public static Customer customerLogin(String email,String password,HashMap<String,Customer> cmap ) throws CustomerHandlingException
	{
		Customer c1=getCustomerDetails(email, cmap);
		String cpassword=c1.getPassword();
		Customer c2=null;
		for(Customer c:cmap.values())
		{
			if(!c.getPassword().equals(password))
			{
				throw new CustomerHandlingException("Wrong password");
			}
			else
			{
				c2=c;
				break;
			}
		}
		
		
		return c2;
	}
	
	public static Address getAddress(String type,HashMap<String,Address> amap) throws CustomerHandlingException
	{
		Address a=amap.get(type);
		if(a==null)
		{
			throw new CustomerHandlingException("Address type does not exist. add new one");
		}
		return a;
	}

}
