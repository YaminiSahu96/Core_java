package utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import com.app.core.Address;
import com.app.core.Customer;
import com.app.core.CustomerType;

import custom_exceptions.CustomerHandlingException;

public class ValidationRules {
	
	public static SimpleDateFormat sdf;
	
	static
	{
		sdf=new SimpleDateFormat("dd-MM-yyyy");
	}

	
	//to check for valid customer type
	public static CustomerType validateCustomerType(String ctype) throws CustomerHandlingException
	{
		CustomerType c=null;
		try
		{
			c=CustomerType.valueOf(ctype);
		}
		catch(Exception e)
		{
			throw new CustomerHandlingException("Invalid Customer Type");                                                                                                                                                                                  
		}
		return c;
	}
	
	//to validate Date
	public static Date validateDate(String regDate) throws CustomerHandlingException
	{
		Date d=null;
		try
		{
			d=sdf.parse(regDate);
		}
		catch(Exception e)
		{
			throw new CustomerHandlingException("Invalid date");
		}
		return d;
		
	}
	
	public static String validateEmailDuplicate(String email,HashMap<String,Customer> cmap) throws CustomerHandlingException
	{
		if(cmap.containsKey(email))
		{
			throw new CustomerHandlingException("Email ID already exist");
		}
		return email;
	}
	
	public static String validateAddressDuplicate(String type,HashMap<String,Address> amap) throws CustomerHandlingException
	{
		if(amap.containsKey(type))
		{
			throw new CustomerHandlingException("Address type already exist");
		}
		return type;
	}
	
	
}
