package utils;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

import com.app.core.Customer;

public class IOUtils 
{
	public static String filename="CustomerRecords";
	
	public static void writeToFile(HashMap<String,Customer> cmap)
	{
			
			try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(filename)))
			{
				out.writeObject(cmap);
				
			}catch(Exception e)
			{
				
			}
		
	}
	public static HashMap<String,Customer> getDateFromFile()
	{
		
		HashMap<String,Customer> cmap=new HashMap<String,Customer>();
		try(ObjectInputStream out=new ObjectInputStream(new FileInputStream(filename)))
		{
			cmap=(HashMap<String, Customer>) out.readObject();
			
		}catch(Exception e)
		{
			
		}
		return cmap;
	}

}
