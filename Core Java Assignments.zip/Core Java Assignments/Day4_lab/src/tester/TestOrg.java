package tester;
import com.app.org.*;
import java.util.*;
import static com.app.org.EmployeeUtils.addEmployee;

public class TestOrg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int ct=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Organization Name:");
		String orgname=sc.next();
		System.out.println("Enter Employee count:");
		int empcount=sc.nextInt();
		
		//Employee e = new Manager();//upcastig
		//Manager m =  (Manager)e;		//downcasting
		Employee emp[]=new Employee[empcount];
		boolean flag=false;
		 String name,email,deptid;
		double basicSal,perfBonus,hourlyRate;
		 int hoursWorked;
		while(!flag)
		{
			System.out.println("*****"+orgname+"*****");
			System.out.println("1. Hire Manager");
			System.out.println("2. Hire Worker");
			System.out.println("3. Display Employee List");
			System.out.println("4. Search Employee");
			System.out.println("5. Increment Salary");
			System.out.println("6. Employee Specific Details ");
			System.out.println("7. Exit");
			System.out.println("Enter your choice:");
			switch(sc.nextInt())
			{
			case 1:
				if(ct<emp.length)
				{
				System.out.println("Enter Manager details ");
				System.out.println("Name:");
				name=sc.next();
				System.out.println("Email:");
				email=sc.next();
				System.out.println("DeptID:");
				deptid=sc.next();
				System.out.println("Basic Salary:");
				basicSal=sc.nextDouble();
				System.out.println("Performance Bonus:");
				perfBonus=sc.nextDouble();
				Employee  m=new Manager(name,email,deptid,basicSal,perfBonus);
					emp[ct++]=m;
				}
				else
				{
					System.out.println("No vacaency");
				}
				//addEmployee(m, emp);
						break;
			case 2:
				if(ct<emp.length)
				{
				System.out.println("Enter Manager details ");
				System.out.println("Name:");
				name=sc.next();
				System.out.println("Email:");
				email=sc.next();
				System.out.println("DeptID:");
				deptid=sc.next();
				System.out.println("Basic Salary:");
				basicSal=sc.nextDouble();
				System.out.println("Hours Worked :");
				hoursWorked=sc.nextInt();
				System.out.println("Hourly Rate :");
				hourlyRate=sc.nextDouble();
				Employee  w=new Worker(name,email,deptid,basicSal,hoursWorked,hourlyRate);
				
					emp[ct++]=w;
				}
				else
				{
					System.out.println("No vacaency");
				}
				//addEmployee(w, emp);
						break;
			case 3:
				
					for (Employee e1: emp)
					{
						if(e1!=null)
					   System.out.println(e1+" net sal :"+e1.calculateNetSal());
					}
				break;
			case 4:
				System.out.println("Enter the employee id that you want to search:");
				int index=sc.nextInt()-100;
				if(index<0 || index >empcount)
				{
					System.out.println("invalid emp id");
				}
				else
				{
					System.out.println(emp[index]);
				
				}
			
				break;
			case 5:
				System.out.println("Enter the employee id to increment the salary:");
				int index1=sc.nextInt()-100;
				System.out.println("Enter the salary to increment:");
				double sal=sc.nextDouble();
				if(index1<0 || index1>empcount)
				{
					System.out.println("invalid emp id");
					
				}
				else
				{
					emp[index1].setBasicSal(sal);
				}
			
				break;
			case 6:
				System.out.println("Enter the id");
				int index2 = sc.nextInt()-100;
				if(index2<0 || index2>empcount)
				{
					System.out.println("invalid emp id");
				}
				else
				{
					Employee e = emp[index2];
					if(e instanceof Manager)
					{
						System.out.println("Manager :"+((Manager)e).getPerfBonus());
					}
					else
					{
						System.out.println("Worker: "+((Worker)e).getHourlyRate());
					}
					
				}
				break;
			case 7:
				flag=true;
				break;
			}
			
			
			
		}
		

	}

}
