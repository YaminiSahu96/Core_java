package com.app.org;
public class EmployeeUtils {
	
	public static int counter=0;
	public static void addEmployee(Employee e,Employee[] emp)
	{
		if(counter < emp.length)
			emp[counter++]=e;
		else
			System.out.println("No vacaency !!!!");
	}
}
