package com.app.org;

public class Worker extends Employee {

	private int hoursWorked;
	private double hourlyRate;
	
	public Worker(String name,String email,String deptid,double basicSal,int hoursWorked,double hourlyRate)
	{
		super(name,email,deptid,basicSal);
		this.hoursWorked=hoursWorked;
		this.hourlyRate=hourlyRate;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String returnString="Worker : "+super.toString()+" hours Worked :"+hoursWorked+" hourly rate:"+hourlyRate;
		return returnString;
	}

	@Override
	public double calculateNetSal() {
		// TODO Auto-generated method stub
		
		return super.getBasicSal()+(hoursWorked*hourlyRate);
	}
	
	public double  getHourlyRate()
	{
		return hourlyRate;
	}
	
	

}
