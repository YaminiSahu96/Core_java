package com.app.org;

public abstract class Employee {
	
	private int id;
	private static int counter;
	private String name,email,deptid;
	double basicSal,netSal;
	
	
	
	public Employee() {
		super();
	}
	static
	{
			counter=100;
	}
	
	public Employee(String name,String email,String deptid,double basicSal )
	{
			id=counter++;
			this.name=name;
			this.email=email;
			this.deptid=deptid;
			this.basicSal=basicSal;
		
	}

	@Override
	public String toString() {
		
		String returnString="id:"+id+
				" name:"+name+
				" email:"+email+
				" deptid:"+deptid+
				" basic sal:"+basicSal;
		return returnString;
	}
	
	public abstract  double calculateNetSal();
	
	public double getBasicSal()
	{
		return basicSal;
	}
	public int  getId()
	{
		return id;
	}
	public void setBasicSal(double sal)
	{
		basicSal=basicSal+sal;
	}
	
	

	

	

}
