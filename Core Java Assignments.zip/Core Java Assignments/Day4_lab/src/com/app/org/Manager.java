package com.app.org;

public class Manager extends Employee {

	private double perfBonus;
	
	public Manager(String name,String email,String deptid,double basicSal,double perfBonus) 
	{
		super(name,email,deptid,basicSal);
		this.perfBonus=perfBonus;

	}
	
	public Manager() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String returnString= "Manager :" + super.toString()+" perfBonus:"+perfBonus;
		return returnString;
	}

	@Override
	public double calculateNetSal() {
		// TODO Auto-generated method stub
			return super.getBasicSal()+perfBonus;
	}

	public double getPerfBonus()
	{
		return perfBonus;
	}
	
}
