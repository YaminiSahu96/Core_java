package p1;

public class Employee1 {

	private int id;
	private String name;
	private String email;
	private int deptid;
	private double basicSal;
	
	static {
		
		
	}
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	
	
	
}
