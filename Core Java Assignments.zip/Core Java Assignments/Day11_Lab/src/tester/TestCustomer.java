package tester;

import static utils.CollectionUtils.customerLogin;
import static utils.CollectionUtils.populateStudent;
import static utils.ValidationRules.validateCustomerType;
import static utils.ValidationRules.validateDate;
import static utils.ValidationRules.validateEmailDuplicate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

import com.app.core.Customer;
public class TestCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(Scanner sc =new Scanner(System.in))
		{
		
		HashMap<String,Customer> cmap=populateStudent();
		
		boolean flag=false;
		while(!flag)
		{
			System.out.println("****** Customer Management System*****");
			System.out.println("1. Register New Customer");
			System.out.println("2. Link Address");
			System.out.println("3. Customer Login");
			System.out.println("4. Unsubsribe Customer");
			System.out.println("5. Display All Customers");
			System.out.println("6. Update Customer");
			System.out.println("7. Sort Customer as per emails");
			System.out.println("8.Sort Customer as per Reg date");
			System.out.println("9. Exit");
			System.out.println("Enter your choice:");
			try
			{
				switch (sc.nextInt()) {
				case 1:
				{
					System.out.println("Enter the customer details: email ,password, reg amount ,reg date,customer type");
					Customer newCustomer=new Customer(validateEmailDuplicate(sc.next(), cmap),sc.next(),sc.nextDouble(),validateDate(sc.next()),validateCustomerType(sc.next()));
					cmap.put(newCustomer.getEmail(), newCustomer);	
					break;
				}
				case 2:
				{
					System.out.println("Enter the email and password");
					Customer c=customerLogin(sc.next(), sc.next(), cmap);
					System.out.println("Enter the address details:city,state,country,phonNo,type");
					//c.linkAddress(sc.next(), sc.next(), sc.next(), sc.next(), sc.next());
				}
				break;
				case 3:
				{
					System.out.println("Enter the email and password");
					Customer c=customerLogin(sc.next(), sc.next(), cmap);
						System.out.println("Logged in successfully");
				}
				break;
				case 4:
				{
					System.out.println("Enter the email and password");
					Customer c=customerLogin(sc.next(), sc.next(), cmap);
					System.out.println(cmap.remove(c.getEmail()));
					System.out.println("Unsubsribed");
				}
				break;
				case 5:
				{
					for(Customer c:cmap.values())
					{
						System.out.println(c);
					}
					
				}
				break;
				case 6:
				{
					System.out.println("Enter the email and password");
					Customer c=customerLogin(sc.next(), sc.next(), cmap);
					System.out.println("Enter the address details:city,state,country,phonNo,type");
				//	c.updateAddress(sc.next(), sc.next(), sc.next(), sc.next(), sc.next());
				}
				break;
				case 7:
				{
					TreeMap<String, Customer> tmap=new TreeMap<String, Customer>(cmap);
					for(Customer c:tmap.values())
					{
						System.out.println(c);
					}
					
				}
				case 8:
				{
					ArrayList< Customer> list=new ArrayList<Customer>(cmap.values());
					Collections.sort(list,new Comparator<Customer>() {

						@Override
						public int compare(Customer c1, Customer c2) {
							return c1.getRegDate().compareTo(c2.getRegDate());
							
						}
					});
					
					for(Customer c:list)
					{
						System.out.println(c);
					}
					
				}
				break;
				
				default:
					break;
				}
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	}
}

}
