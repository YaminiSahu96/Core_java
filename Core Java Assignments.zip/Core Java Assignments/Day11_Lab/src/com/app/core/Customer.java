package com.app.core;

import static utils.ValidationRules.sdf;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Customer {

	String email,password;
	double regAmount;
	Date regDate;
	CustomerType ctype;
	HashMap<String,Address> addresses;
	
	public Customer(String email, String password, double regAmount, Date regDate, CustomerType ctype) {
		super();
		this.email = email;
		this.password = password;
		this.regAmount = regAmount;
		this.regDate = regDate;
		this.ctype = ctype;
		this.addresses=new HashMap<String,Address>();
	}


	public void linkAddress(String city,String state,String country,String phoneNo,String type)
	{
		Address addr=new Address(city, state, country, phoneNo, type);
		addresses.put(addr.getAdrtype(), addr);
	}
	
	public void updateAddress(String city,String state,String country,String phoneNo,String type)
	{
		if(addresses.size()>0)
		{
			Address a=addresses.get(type);
			a.setCity(city);
			a.setCountry(country);
			a.setPhonNo(phoneNo);
			a.setState(state);
			a.setAdrtype(type);
			
		}
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public double getRegAmount() {
		return regAmount;
	}


	public void setRegAmount(double regAmount) {
		this.regAmount = regAmount;
	}


	public Date getRegDate() {
		return regDate;
	}


	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}


	public CustomerType getCtype() {
		return ctype;
	}


	public void setCtype(CustomerType ctype) {
		this.ctype = ctype;
	}


	@Override
	public String toString() {
		
		String str="";
		for(Address a:addresses.values())
		{
			str=str+a.toString();
		}
		return "Customer [email=" + email + ", password=" + password + ", regAmount=" + regAmount + ", regDate="
				+ sdf.format(regDate)+ ", ctype=" + ctype + "Address="+str+"]";
	}
	
	
	
	
	
	
}
