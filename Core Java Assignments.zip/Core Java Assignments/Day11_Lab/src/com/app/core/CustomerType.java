package com.app.core;

public enum CustomerType {
		SILVER,GOLD,PLATINUM

}
