package com.app.core;

public enum AddressType {
	
	HOME,EMAIL,OFFICE

}
