package com.app;

class Calculator
{
	private double fno,sno;
	
	void setFno(double value)
	{
		fno=value;
	}
	void setSno(double value)
	{
		sno=value;
	}
	double getFno()
	{
		return fno;
	}
	double getSno()
	{
		return sno;
	}
	
	double addNumber()
	{
			return fno+sno;
	}
	double subNumber()
	{
			return fno-sno;
	}
	double mulNumber()
	{
			return fno*sno;
	}
	double divNumber()
	{
		if(sno==0)
		{
			return 0;
		}
			return fno/sno;
	}
	
	

}