package tester;
import java.util.Scanner;
class GenerateBill 
{
	public static void main(String[] args) 
	{
		double totalbill=0.00;
		int quantity=0;
		Scanner sc=new Scanner(System.in);
		boolean flag =false;
		while(!flag)
		{
		System.out.println("******Arya's Restaurant******");
		System.out.println("1. Dosa   30");
		System.out.println("2. Paratha 40");
		System.out.println("3. Idli 30");
		System.out.println("4. Sandwitch 20");
		System.out.println("5. Pakode  30");
		System.out.println("6. Wadapav 20");
		System.out.println("7. Poha 20");
		System.out.println("8. Chinese 60");
		System.out.println("9. Manchurian 20");
		System.out.println("10. Generate Bill");
		System.out.println("11. Exit");
		System.out.println("Enter your choice:");
		switch(sc.nextInt())
		{
			case 1:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 30);
					break;
			case 2:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 40);
					break;
			
			case 3:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 30);
					break;

			case 4:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 20);
					break;
			case 5:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 30);
					break;

			case 6:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 20);
					break;
			case 7:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 20);
					break;

			case 8:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 60);
					break;
			case 9:
					System.out.println("Enter quantity:");
					quantity=sc.nextInt();
					totalbill=totalbill+(quantity * 20);
					break;
			case 10:
					System.out.println("Your total bill is ="+totalbill);
					
					break;
			case 11:
					flag=true;
					
					break;
		}
		}


	}
}
