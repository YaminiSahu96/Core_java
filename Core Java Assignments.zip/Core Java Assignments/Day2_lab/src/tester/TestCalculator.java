package tester;
import com.app.Calculator;
import java.util.Scanner;
class TestCalculator
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		Calculator c=new Calculator();
		c.setFno(sc.nextDouble());
		c.setSno(sc.nextDouble());
		boolean flag=false;
		double result=0.00;
		while(!flag)
		{
			System.out.println("Calculator");
			System.out.println("1. Add");
			System.out.println("2. Sub");
			System.out.println("3. Mul");
			System.out.println("4. Div");
			System.out.println("5. Exit");
			System.out.println("Enter your choice:");
			switch(sc.nextInt())
			{
				case 1:
						result=c.addNumber();
						System.out.println("Result="+result);
						break;
				case 2:
						result=c.subNumber();
						System.out.println("Result="+result);
						break;
				case 3:
						result=c.mulNumber();
						System.out.println("Result="+result);
						break;
				case 4:
						result=c.divNumber();
						System.out.println("Result="+result);
						break;
				case 5:
						flag=true;
						break;
			}
		}
		
	}
}