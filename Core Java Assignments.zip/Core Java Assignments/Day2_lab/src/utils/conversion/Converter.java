package utils.conversion;
import java.util.Scanner;
public class Converter 
{
	
	public static double convertPondToKG(int pvalue)
	{
			return pvalue * 0.4536;
	}
	public static double convertTempToFaren(int cvalue)
	{
			return cvalue* 9/5 + 32;
	}
	public static String convertSecondToString(int svalue)
	{
				int hr=svalue/3600;
				int min=(svalue%3600)/60;
				int sec=((svalue%3600)/60)*60;
				String str="Hr:"+String.valueOf(hr)+" "+"Min:"+String.valueOf(min)+" "+"Sec:"+String.valueOf(sec).substring(0,2);
				return str;
	}

}
