package utils.conversion;
import  utils.conversion.Converter;
import java.util.Scanner;
class TestConverter
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		boolean flag=false;
		while(!flag)
		{
			System.out.println("***Converter ***");
			System.out.println("1. Ponds to KG");
			System.out.println("2. Celcius to Farenhit");
			System.out.println("3. Seconds to Fomatted String");
			System.out.println("4. Exit");
			System.out.println("Enter your choice:");
			switch(sc.nextInt())
			{
				case 1:
						System.out.println("Enter ponds:");
						System.out.println("KG:"+Converter.convertPondToKG(sc.nextInt()));
					break;
				case 2:
						System.out.println("Enter celcius:");
						System.out.println("Farenhit:"+Converter.convertTempToFaren(sc.nextInt()));
					break;
				case 3:
						System.out.println("Enter seconds:");
						System.out.println("String:"+Converter.convertSecondToString(sc.nextInt()));
					break;
				case 4:
						flag=true;
					break;
				
			}
		}
	}
}
